"""
===============================================================================
2D PROPERTY 07: 2D SPATIAL REVERSAL
===============================================================================
Mathematical Formula:
    Spatial Domain:   y(t1, t2) = x(-t1, -t2)
    Frequency Domain: Y(u, v)   = X(-u, -v)
===============================================================================
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import RegularGridInterpolator

def compute_2d_cft(signal_2d, t1, t2, u, v):
    T1, T2 = np.meshgrid(t1, t2)
    X_uv = np.zeros((len(v), len(u)), dtype=complex)
    for i, v_val in enumerate(v):
        for j, u_val in enumerate(u):
            kernel = np.exp(-1j * 2 * np.pi * (u_val * T1 + v_val * T2))
            integrand = signal_2d * kernel
            if hasattr(np, 'trapezoid'):
                int_t1 = np.trapezoid(integrand, t1, axis=1)
                X_uv[i, j] = np.trapezoid(int_t1, t2, axis=0)
            else:
                int_t1 = np.trapz(integrand, t1, axis=1)
                X_uv[i, j] = np.trapz(int_t1, t2, axis=0)
    return X_uv

def interp2d_complex(X_uv, u_grid, v_grid, u_target, v_target):
    interp_r = RegularGridInterpolator((v_grid, u_grid), X_uv.real, bounds_error=False, fill_value=0.0)
    interp_i = RegularGridInterpolator((v_grid, u_grid), X_uv.imag, bounds_error=False, fill_value=0.0)
    U_tar, V_tar = np.meshgrid(u_target, v_target)
    pts = np.stack([V_tar.ravel(), U_tar.ravel()], axis=-1)
    return (interp_r(pts) + 1j * interp_i(pts)).reshape(len(v_target), len(u_target))

t1 = np.linspace(-3, 3, 80)
t2 = np.linspace(-3, 3, 80)
T1, T2 = np.meshgrid(t1, t2)

u = np.linspace(-3, 3, 50)
v = np.linspace(-3, 3, 50)

# Asymmetric 2D signal
x = np.where((T1 >= 0) & (T2 >= 0), np.exp(-2.0 * T1 - 1.5 * T2), 0.0)
y = np.where((-T1 >= 0) & (-T2 >= 0), np.exp(-2.0 * (-T1) - 1.5 * (-T2)), 0.0)

X_uv = compute_2d_cft(x, t1, t2, u, v)
Y_num = compute_2d_cft(y, t1, t2, u, v)

# Theoretical: X(-u, -v)
Y_theo = interp2d_complex(X_uv, u, v, -u, -v)

mse_mag = np.mean((np.abs(Y_num) - np.abs(Y_theo)) ** 2)
print(f"[07. 2D Time Reversal] Magnitude MSE : {mse_mag:.6e}")

fig, axs = plt.subplots(1, 3, figsize=(14, 4))
axs[0].imshow(y, extent=[t1[0], t1[-1], t2[0], t2[-1]], origin='lower', cmap='viridis')
axs[0].set_title(r'Reversed $y(t_1, t_2) = x(-t_1, -t_2)$')
axs[1].imshow(np.abs(Y_num), extent=[u[0], u[-1], v[0], v[-1]], origin='lower', cmap='plasma')
axs[1].set_title(r'Numerical $|Y(u, v)|$')
axs[2].imshow(np.abs(np.abs(Y_num) - np.abs(Y_theo)), extent=[u[0], u[-1], v[0], v[-1]], origin='lower', cmap='inferno')
axs[2].set_title('Absolute Magnitude Error')
plt.tight_layout(); plt.show()
